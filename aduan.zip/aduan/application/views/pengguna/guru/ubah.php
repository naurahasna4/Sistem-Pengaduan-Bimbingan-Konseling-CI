<div class="card pt-4 pl-5 pr-5">
    <form action="" method="post">
        <div class="form-group row">
            <label for="nuptk" class="col-sm-3 col-form-label">NUPTK</label>
            <div class="col-sm-8">
                <input type="number" name="nuptk" id="nuptk" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $guru->nuptk ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('nuptk', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="nama_guru" class="col-sm-3 col-form-label">Nama Guru BK</label>
            <div class="col-sm-8">
                <input type="text" name="nama_guru" id="nama_guru" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $guru->nama_guru ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('nama_guru', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="jenis_kelamin" class="col-sm-3 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-8">
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                    <option value="laki-laki" <?php if ($guru->jenis_kelamin == 'laki-laki') {
                                                    echo "selected";
                                                } ?>>laki-laki</option>
                    <option value="perempuan" <?php if ($guru->jenis_kelamin == 'perempuan') {
                                                    echo "selected";
                                                } ?>>perempuan</option>
                </select>
                <small id="helpId" class="text-muted"><?php echo form_error('jenis_kelamin', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="alamat" class="col-sm-3 col-form-label">Alamat</label>
            <div class="col-sm-8">
                <input type="text" name="alamat" id="alamat" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $guru->alamat ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('alamat', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="telp" class="col-sm-3 col-form-label">No Telpon</label>
            <div class="col-sm-8">
                <input type="number" name="telp" id="telp" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $guru->telp ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('telp', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <br>
        <div class="form-group row justify-content-center">
            <button type="submit" class="btn btn-primary mr-2">Simpan</button>
            <a href="<?= base_url('admin/pengguna/guru') ?>" class="btn btn-warning mr-2">Kembali</a>
            <button type="reset" class="btn btn-danger mr-2">Reset</button>
        </div>
    </form>
</div>
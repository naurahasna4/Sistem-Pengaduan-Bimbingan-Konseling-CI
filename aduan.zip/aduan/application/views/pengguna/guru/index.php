<div class="card mb-4">
    <div class="card-header">
        <a href="<?= base_url('admin/pengguna/guru/tambah') ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="exampleLaporan" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NUPTK</th>
                        <th>Nama Guru BK</th>
                        <th>Jenis Kelamin</th>
                        <th>Alamat</th>
                        <th>No Telepon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($pengguna_guru as $pp) { ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $pp['nuptk'] ?></td>
                            <td><?= $pp['nama_guru'] ?></td>
                            <td><?= $pp['jenis_kelamin'] ?></td>
                            <td><?= $pp['alamat'] ?></td>
                            <td><?= $pp['telp'] ?></td>
                            <td>
                                <a href="<?= base_url('admin/pengguna/guru/edit/') ?><?= $pp['id'] ?>" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                                <a href="<?= base_url('admin/pengguna/guru/hapus/') ?><?= $pp['id'] ?>" class="btn btn-danger"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
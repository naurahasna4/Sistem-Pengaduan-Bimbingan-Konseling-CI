<div class="card pt-4 pl-5 pr-5">
    <form action="" method="post">
        <div class="form-group row">
            <label for="nis" class="col-sm-3 col-form-label">NIS</label>
            <div class="col-sm-8">
                <input type="text" name="nis" id="nis" class="form-control" placeholder="Masukkan Nomor Induk Siswa" aria-describedby="helpId" value="<?= set_value('nis') ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('nis', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="nama" class="col-sm-3 col-form-label">Nama Siswa</label>
            <div class="col-sm-8">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="Masukkan Nama Siswa" aria-describedby="helpId" value="<?= set_value('nama') ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('nama', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="kelas" class="col-sm-3 col-form-label">Kelas</label>
            <div class="col-sm-8">
                <input type="text" name="kelas" id="kelas" class="form-control" placeholder="Masukkan Kelas" aria-describedby="helpId" value="<?= set_value('kelas') ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('kelas', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="alamat" class="col-sm-3 col-form-label">Alamat</label>
            <div class="col-sm-8">
                <input type="text" name="alamat" id="alamat" class="form-control" placeholder="Masukkan Alamat" aria-describedby="helpId" value="<?= set_value('alamat') ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('alamat', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="jenis_kelamin" class="col-sm-3 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-8">
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                    <option value="" selected disabled>-- Pilih Jenis Kelamin --</option>
                    <option value="laki-laki" value="<?= set_select('jenis_kelamin') ?>">Laki-Laki</option>
                    <option value="perempuan" value="<?= set_select('jenis_kelamin') ?>">Perempuan</option>
                </select>
                <small id="helpId" class="text-muted"><?php echo form_error('jenis_kelamin', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="username" class="col-sm-3 col-form-label">Username</label>
            <div class="col-sm-8">
                <input type="text" name="username" id="username" class="form-control" placeholder="Masukkan Username" aria-describedby="helpId" value="<?= set_value('username') ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('username', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="password" class="col-sm-3 col-form-label">Password</label>
            <div class="col-sm-8">
                <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password" aria-describedby="helpId" value="<?= set_value('password') ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('password', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="telp" class="col-sm-3 col-form-label">No. Telepon</label>
            <div class="col-sm-8">
                <input type="number" name="telp" id="telp" class="form-control" placeholder="Masukkan No. Telepon" aria-describedby="helpId" value="<?= set_value('telp') ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('telp', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <br>
        <div class="form-group row justify-content-center">
            <button type="submit" class="btn btn-primary mr-2">Simpan</button>
            <a href="<?= base_url('admin/pengguna/siswa') ?>" class="btn btn-warning mr-2">Kembali</a>
            <button type="reset" class="btn btn-danger mr-2">Reset</button>
        </div>
    </form>
</div>
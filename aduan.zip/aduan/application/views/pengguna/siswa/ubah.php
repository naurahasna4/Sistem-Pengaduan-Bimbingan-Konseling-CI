<div class="card pt-4 pl-5 pr-5">
    <form action="" method="post">
        <div class="form-group row">
            <label for="nis" class="col-sm-3 col-form-label">NIS</label>
            <div class="col-sm-8">
                <input type="number" name="nis" id="nis" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $siswa->nis ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('nis', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="nama" class="col-sm-3 col-form-label">Nama Siswa</label>
            <div class="col-sm-8">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $siswa->nama ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('nama', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="kelas" class="col-sm-3 col-form-label">Kelas</label>
            <div class="col-sm-8">
                <input type="text" name="kelas" id="kelas" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $siswa->kelas ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('kelas', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="alamat" class="col-sm-3 col-form-label">Alamat</label>
            <div class="col-sm-8">
                <input type="text" name="alamat" id="alamat" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $siswa->alamat ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('alamat', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="jenis_kelamin" class="col-sm-3 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-8">
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                    <option value="laki-laki" <?php if ($siswa->jenis_kelamin == 'laki-laki') {
                                                    echo "selected";
                                                } ?>>laki-laki</option>
                    <option value="perempuan" <?php if ($siswa->jenis_kelamin == 'perempuan') {
                                                    echo "selected";
                                                } ?>>perempuan</option>
                </select>
                <small id="helpId" class="text-muted"><?php echo form_error('jenis_kelamin', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="telp" class="col-sm-3 col-form-label">No Telpon</label>
            <div class="col-sm-8">
                <input type="number" name="telp" id="telp" class="form-control" placeholder="" aria-describedby="helpId" value="<?= $siswa->telp ?>">
                <small id="helpId" class="text-muted"><?php echo form_error('telp', '<div class="alert alert-danger mt-2">', '</div>'); ?></small>
            </div>
        </div>
        <br>
        <div class="form-group row justify-content-center">
            <button type="submit" class="btn btn-primary mr-2">Simpan</button>
            <a href="<?= base_url('admin/pengguna/siswa') ?>" class="btn btn-warning mr-2">Kembali</a>
            <button type="reset" class="btn btn-danger mr-2">Reset</button>
        </div>
    </form>
</div>
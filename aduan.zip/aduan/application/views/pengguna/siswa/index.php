<div class="card mb-4">
    <div class="card-header">
        <a href="<?= base_url('admin/pengguna/siswa/tambah') ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="exampleLaporan" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama</th>
                        <th>Kelas</th>
                        <th>Alamat</th>
                        <th>Username</th>
                        <th>No Telepon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($pengguna_siswa as $pp) { ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $pp['nis'] ?></td>
                            <td><?= $pp['nama'] ?></td>
                            <td><?= $pp['kelas'] ?></td>
                            <td><?= $pp['alamat'] ?></td>
                            <td><?= $pp['username'] ?></td>
                            <td><?= $pp['telp'] ?></td>
                            <td>
                                <a href="<?= base_url('admin/pengguna/siswa/edit/') ?><?= $pp['id'] ?>" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                                <a href="<?= base_url('admin/pengguna/siswa/hapus/') ?><?= $pp['id'] ?>" class="btn btn-danger"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
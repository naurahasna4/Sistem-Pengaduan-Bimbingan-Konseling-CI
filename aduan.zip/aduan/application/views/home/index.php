<div class="jumbotron jumbotron-fluid mt-4">
    <div class="container">
        <h1 class="display-4 text-center">Sistem Pengaduan Bimbingan Konseling</h1>
        <h2 class="text-center" style="text-transform: capitalize">Halo,
            <?= $this->session->userdata('user')['session_nama_siswa'] ?>
        </h2>
        <br>
        <div class="text-center"><img src="<?= base_url('assets/img/hasten.jpg'); ?>"></div>
        <br>
        <h5 class="text-center">SMP Hasanuddin 10 Semarang</h5>
        <h6 class="text-center">Jl. Sedayu Tugu RT.06 RW.05, Sembungharjo, Genuk, Kota Semarang</h6>
        <h6 class="text-center">(024) 6583042</h6>
        <h6 class="text-center">Akreditasi A</h6>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-xl-4 col-md-6">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body text-center">Jumlah Pengaduan</div>
            <div class="card-footer d-flex align-items-center justify-content-center">
                <h4><?= $jumlah_pengaduan ?></h4>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body text-center">Pengaduan Belum Selesai</div>
            <div class="card-footer d-flex align-items-center justify-content-center">
                <h4><?= $jumlah_pengaduan_belum ?></h4>
            </div>
        </div>
    </div>
</div>
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->cekUser();
    }


    public function index()
    {
        $nis = $this->session->userdata('user')['session_nis'];
        $where = [
            'nis'       => $nis
        ];
        $jml_pengaduan = $this->M_all->tampilSatu('tb_pengaduan', $where)->num_rows();
        $jml_pengaduan_belum = $this->M_all->homeHitungPengaduanBelum($nis)->num_rows();
        $data = [
            "jumlah_pengaduan"          => $jml_pengaduan,
            "jumlah_pengaduan_belum"    => $jml_pengaduan_belum,
            "title"                     => 'SIADUBK',
            "content"                   => 'home/index'
        ];
        $this->load->view('template/view', $data, FALSE);
    }
}

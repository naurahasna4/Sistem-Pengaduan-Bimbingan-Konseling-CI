<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function index()
    {
        if (!isset($_SESSION['user'])) {

            redirect(base_url('auth/login'), 'refresh');
        } else {
            redirect(base_url(''), 'refresh');
        }
    }

    public function login()
    {
        $this->load->view('home/login');
    }

    public function masuk()
    {
        $username = htmlspecialchars($this->input->post("username"));
        $password = htmlspecialchars($this->input->post("password"));

        $where = [
            'username'  => $username
        ];

        $cek_user = $this->M_all->tampilSatu('tb_siswa', $where);

        if ($cek_user->num_rows() > 0) {
            $data_user = $cek_user->row();
            $hash_password = SHA1($password);
            // var_dump($data_user);die;
            if ($data_user->password === $hash_password) {

                $array = array(
                    "session_id"                => $data_user->id,
                    "session_nis"               => $data_user->nis,
                    "session_nama_siswa"        => $data_user->nama,
                    "session_username"          => $data_user->username,
                    "session_password"          => $data_user->password
                );

                $this->session->set_userdata("user", $array);
                $this->session->unset_userdata('admin');

                redirect(base_url(''), 'refresh');
            } else {
                $this->session->set_flashdata('pesan-login', 'Password salah');
                redirect(base_url('auth/login'), 'refresh');
            }
        } else {
            $this->session->set_flashdata('pesan-login', 'Username tidak ada');
            redirect(base_url('auth/login'), 'refresh');
        }
    }

    public function logOut()
    {
        $this->session->unset_userdata('user');

        redirect(base_url('auth/login'), 'refresh');
    }
}

/* End of file Auth.php */

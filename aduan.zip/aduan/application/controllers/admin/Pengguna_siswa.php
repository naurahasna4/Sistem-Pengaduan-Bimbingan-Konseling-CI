<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengguna_siswa extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->cekAdmin();
    }

    public function index()
    {
        $Pengguna_siswa = $this->M_all->tampilSemua('tb_siswa')->result_array();
        $data = [
            "pengguna_siswa"  => $Pengguna_siswa,
            "title"                => 'Data Siswa',
            "breadcumb"            => 'Form Data Siswa',
            "content"              => 'pengguna/siswa/index'
        ];
        $this->load->view('template/view', $data, FALSE);
    }

    public function hapus($id)
    {
        $where = [
            'id'    => $id
        ];
        $hapus = $this->M_all->hapus('tb_siswa', $where);
        if ($hapus) {
            echo "<script>";
            echo "alert('Data berhasil dihapus')";
            echo "</script>";
            redirect('admin/pengguna/siswa', 'refresh');
        } else {
            echo "<script>";
            echo "alert('Data gagal dihapus')";
            echo "</script>";
            redirect('admin/pengguna/siswa', 'refresh');
        }
    }

    public function edit($id)
    {
        $this->form_validation->set_rules('nis', 'NIS', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('nama', 'Nama Siswa', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('kelas', 'Kelas', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('alamat', 'Alamat', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('telp', 'No Telepon', 'numeric|required', ['required' => '%s harus diisi', 'numeric' => '%s harus angka']);


        if ($this->form_validation->run() == TRUE) {
            $data = [
                'nis' => htmlspecialchars($this->input->post('nis')),
                'nama' => htmlspecialchars($this->input->post('nama')),
                'kelas' => htmlspecialchars($this->input->post('kelas')),
                'alamat' => htmlspecialchars($this->input->post('alamat')),
                'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin')),
                'password' => SHA1(htmlspecialchars($this->input->post('password'))),
                'telp' => htmlspecialchars($this->input->post('telp'))
            ];
            $where = [
                'id'    =>  $id
            ];
            $ubah = $this->M_all->ubah('tb_siswa', $data, $where);
            // var_dump($ubah);die;
            if ($ubah) {
                echo "<script>";
                echo "alert('Data berhasil diubah')";
                echo "</script>";
                redirect(base_url('admin/pengguna/siswa'), 'refresh');
            } else {
                echo "<script>";
                echo "alert('Data gagal diubah')";
                echo "</script>";
                redirect(base_url('admin/pengguna/siswa/ubah'), 'refresh');
            }
        } else {
            $where = [
                'id'    =>  $id
            ];
            $siswa = $this->M_all->tampilSatu('tb_siswa', $where)->row();
            $data = [
                "siswa"           => $siswa,
                "title"             => 'Edit Data Siswa',
                "breadcumb"         => 'Form Edit Data Siswa',
                "content"           => 'pengguna/siswa/ubah'
            ];
            $this->load->view('template/view', $data, FALSE);;
        }
    }

    public function tambah()
    {
        $this->form_validation->set_rules('nis', 'NIS', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('nama', 'Nama Siswa', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('kelas', 'Kelas', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('alamat', 'Alamat', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[tb_siswa.username]', ['required' => '%s harus diisi', 'is_unique' => '%s tidak boleh sama']);
        $this->form_validation->set_rules('password', 'Password', 'required', ['required' => '%s harus diisi']);
        $this->form_validation->set_rules('telp', 'No Telepon', 'numeric|required', ['required' => '%s harus diisi', 'numeric' => '%s harus angka']);


        if ($this->form_validation->run() == TRUE) {
            $data = [
                'nis' => htmlspecialchars($this->input->post('nis')),
                'nama' => htmlspecialchars($this->input->post('nama')),
                'kelas' => htmlspecialchars($this->input->post('kelas')),
                'alamat' => htmlspecialchars($this->input->post('alamat')),
                'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin')),
                'username' => htmlspecialchars($this->input->post('username')),
                'password' => SHA1(htmlspecialchars($this->input->post('password'))),
                'telp' => htmlspecialchars($this->input->post('telp'))
            ];
            $tambah = $this->M_all->simpan('tb_siswa', $data);
            if ($tambah) {
                echo "<script>";
                echo "alert('Data berhasil ditambah')";
                echo "</script>";
                redirect(base_url('admin/pengguna/siswa'), 'refresh');
            } else {
                echo "<script>";
                echo "alert('Data gagal ditambah')";
                echo "</script>";
                redirect(base_url('admin/pengguna/siswa/tambah'), 'refresh');
            }
        } else {
            $data = [
                "title"             => 'Tambah User Siswa',
                "breadcumb"         => 'Form Tambah User Siswa BK',
                "content"           => 'pengguna/siswa/tambah'
            ];
            $this->load->view('template/view', $data, FALSE);;
        }
    }
}

/* End of file Pengguna_siswa.php */
